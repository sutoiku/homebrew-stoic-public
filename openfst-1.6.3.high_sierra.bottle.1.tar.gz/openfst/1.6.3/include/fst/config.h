/* src/include/fst/config.h.  Generated from config.h.in by configure.  */
// OpenFst config file 

/* Define to 1 if you have the ICU library. */
/* #undef HAVE_ICU */

/* Define to 1 if the system has the type `std::tr1::hash<long long
   unsigned>'. */
#define HAVE_STD__TR1__HASH_LONG_LONG_UNSIGNED_ 1

/* Define to 1 if the system has the type `__gnu_cxx::slist<int>'. */
#define HAVE___GNU_CXX__SLIST_INT_ 1
